<?php
$telegram_id = "6136699793";
$id_bot = "6019837764:AAHXuMxH58mm9WKs9mOrYgNxhK64do14nC0";
?>
